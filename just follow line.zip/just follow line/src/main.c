#include <kipr/wombat.h>

int main()
{ 
	while (digital(0) == 0)
	{ 
    	if (analog(0) > 1600)
    	{ 
        	motor(0, 90); 
        	motor(2, 5); 
		} 
     	else 
     	{ 
        	motor(0, 5); 
        	motor(2, 90); 
		} 
	} 
             
 ao();
    
 return 0;
}
